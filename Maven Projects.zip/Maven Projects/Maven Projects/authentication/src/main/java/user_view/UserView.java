package user_view;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import user_service.UserService;
import userdao.UserDAO;
import userdto.UserDTO;
import userprofiledto.UserProfileDTO;

public class UserView {
    private UserService userService;
    private Scanner scanner;

    public UserView(UserService userService) {
        this.userService = userService;
        this.scanner = new Scanner(System.in);
    }

    public void run() {
    	System.out.println("WELCOME");
    	System.out.println("====================================================");
        while (true) {
            System.out.println("1: Login");
            System.out.println("2: Add User");
            System.out.println("3: Exit");
            System.out.println("====================================================");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            System.out.println("====================================================");

            switch (choice) {
                case 1:
                    login();
                    break;
                case 2:
                    addUser();
                    break;
                case 3:
                    System.out.println("GOOD BYE ...");
                    System.out.println("====================================================");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
                    System.out.println("====================================================");
            }
        }
    }

    private void login() {
        System.out.print("Enter userid: ");
        String userId = scanner.next();
        System.out.print("Enter password: ");
        String password = scanner.next();
        System.out.println("====================================================");
        try {
            UserDTO user = userService.getUserById(userId);
            String userName = userService.getUserNameById(userId);

            if (user != null && user.getPassword().equals(password)) {
                System.out.println("Welcome " + userName);
                System.out.println("====================================================");
                
                String url = "jdbc:mysql://localhost:3306/colors";
            	String username = "root";
            	String pass = "root";
                Connection connection = DriverManager.getConnection(url, username, pass);
                String sql = "UPDATE user SET status = 'A', logged = 'Y' WHERE userid = ?";
                PreparedStatement preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setString(1, userId);
                int updatedRows = preparedStatement.executeUpdate();
                
                while (true) {
                    System.out.println("1: Change Password");
                    System.out.println("2: Change Profile");
                    System.out.println("3: Logout");
                    System.out.println("====================================================");
                    System.out.print("Enter your choice: ");
                    int subChoice = scanner.nextInt();
                    System.out.println("====================================================");

                    switch (subChoice) {
                        case 1:
                        	System.out.println("Enter Old Password");
                        	String oldPassword = scanner.next();
                        	if (user.getPassword().contains(oldPassword)) {
                        		System.out.println("Enter new password: ");
                                String newPassword = scanner.next();
                                System.out.println("Conform Password");
                                String confirm = scanner.next();
                                System.out.println("====================================================");
                                if (newPassword.contains(confirm)) {
                                	boolean updated = userService.updateUserPassword(userId, newPassword);
                                    if (updated) {
                                        System.out.println("Password changed successfully.");
                                        System.out.println("====================================================");
                                        user.setPassword(newPassword);
                                    } else {
                                        System.out.println("Password change failed.");
                                        System.out.println("====================================================");
                                    }
								}else {
									System.out.println("New Password And Confirm Password Does'n Match");
									System.out.println("====================================================");
								}
							}else {
								System.out.println("Enter Correct Old Password");
								System.out.println("====================================================");
							}                        
                            break;
                        case 2:
                        	System.out.println("Enter First Name");
                        	String firstName = scanner.next();
                        	System.out.println("Enter Last Name");
                        	String lastName = scanner.next();
                        	System.out.println("Enter Email Id");
                        	String email = scanner.next();
                        	System.out.println("Enter Mobile Number");
                        	String mobile = scanner.next();
                        	System.out.println("Enter Adress");
                        	String address = scanner.nextLine(); 
                        	address = scanner.nextLine();
                        	System.out.println("Enter City");
                        	String city = scanner.next();
                        	System.out.println("====================================================");
                        	UserProfileDTO updatedProfile = new UserProfileDTO(userId, firstName, lastName, email, address, city, mobile);

                            try {
                                boolean updateProfile = userService.updateUserProfile(updatedProfile);
                                if (updateProfile) {
                                    System.out.println("Profile updated successfully.");
                                    System.out.println("====================================================");
                                } else {
                                    System.out.println("Profile update failed.");
                                    System.out.println("====================================================");
                                }
                            } catch (SQLException e) {
                                e.printStackTrace();
                            }
                            break;
                        case 3:
                            System.out.println("Logged out.");
                            System.out.println("====================================================");
                            sql = "UPDATE user SET status = 'NA', logged = 'N' WHERE userid = ?";
                            preparedStatement = connection.prepareStatement(sql);
                            preparedStatement.setString(1, userId);
                            updatedRows = preparedStatement.executeUpdate(); 
                            return;
                        default:
                            System.out.println("Invalid choice. Please try again.");
                            System.out.println("====================================================");
                    }
                }
            } else {
                System.out.println("Login failed. Invalid credentials.");
                System.out.println("====================================================");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    private void addUser() {
        // Gather user input for creating a new user profile
        System.out.print("Enter userid: ");
        String userId = scanner.next();
        System.out.print("Enter password: ");
        String password = scanner.next();
        System.out.print("Enter first name: ");
        String firstName = scanner.next();
        System.out.print("Enter last name: ");
        String lastName = scanner.next();
        System.out.print("Enter email: ");
        String email = scanner.next();
        System.out.print("Enter address: ");
        String address = scanner.next();
        System.out.print("Enter city: ");
        String city = scanner.next();
        System.out.print("Enter mobile no: ");
        String mobileNo = scanner.next();
        System.out.println("====================================================");

        // Create a UserProfileDTO object with the gathered information
        UserProfileDTO userProfile = new UserProfileDTO(userId, firstName, lastName, email, address, city, mobileNo);
        UserDTO user = new UserDTO(userId, password);
        try {
        	boolean add = userService.addUser(user);
        	if (add) {
        		boolean added = userService.addUserProfile(userProfile);
                if (added) {
                    System.out.println("User profile added successfully.");
                    System.out.println("====================================================");
                } else {
                    System.out.println("User profile addition failed.");
                    System.out.println("====================================================");
                }
			}            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}