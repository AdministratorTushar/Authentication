package userdto;

public class UserDTO {
    private String userId;
    private String password;
    private String status = "NA"; // Default value
    private String doj;
    private String logged = "N";

    // Constructors, getters, and setters
    public UserDTO(String userId, String password) {
        this.userId = userId;
        this.password = password;
    }

    public UserDTO() {
	}

	public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDoj() {
        return doj;
    }

    public void setDoj(String doj) {
        this.doj = doj;
    }

    public String getLogged() {
        return logged;
    }

    public void setLogged(String logged) {
        this.logged = logged;
    }
}