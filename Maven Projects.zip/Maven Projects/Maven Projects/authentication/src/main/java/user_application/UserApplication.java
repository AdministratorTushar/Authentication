package user_application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import user_service.UserService;
import user_view.UserView;
import userdao.UserDAO;
import userprofiledao.UserProfileDAO;

public class UserApplication {
	static String url = "jdbc:mysql://localhost:3306/colors";
	static String username = "root";
	static String password = "root"; 
	
    public static void main(String[] args) {
        try{
        	Connection connection = DriverManager.getConnection(url, username, password);
            UserDAO userDAO = new UserDAO(connection);
            UserProfileDAO userProfileDAO = new UserProfileDAO(connection);
            UserService userService = new UserService(connection, userDAO, userProfileDAO);
            UserView userView = new UserView(userService);
            userView.run();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}