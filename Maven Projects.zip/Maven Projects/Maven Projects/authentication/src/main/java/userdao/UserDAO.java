package userdao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import userdto.UserDTO;
import userprofiledto.UserProfileDTO;

public class UserDAO {
    private Connection connection;

    public UserDAO(Connection connection) {
        this.connection = connection;
    }

    public UserDAO() {
	}

	public UserDTO getUserById(String userId) {
        String sql = "SELECT * FROM user WHERE userid = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, userId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    UserDTO user = new UserDTO(
                            resultSet.getString("userid"),
                            resultSet.getString("password")
                            
                    );
                    user.setStatus(resultSet.getString("status"));
                    return user;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean updateUserPassword(String userId, String newPassword) {
        String sql = "UPDATE user SET password = ? WHERE userid = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, newPassword);
            statement.setString(2, userId);
            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public String getUserNameById(String userId) {
        String sql = "SELECT firstName, lastName FROM user_info WHERE userid = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, userId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    String firstName = resultSet.getString("firstName");
                    String lastName = resultSet.getString("lastName");
                    return firstName + " " + lastName;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    
    public boolean addUser(UserDTO user) {
        String insertCredentialsQuery = "INSERT INTO user (userId, password) VALUES (?, ?)";
        
        try (PreparedStatement credentialsStatement = connection.prepareStatement(insertCredentialsQuery)) {
             
            credentialsStatement.setString(1, user.getUserId());
            credentialsStatement.setString(2, user.getPassword());
            
            int rowsAffected = credentialsStatement.executeUpdate();
            
            return rowsAffected > 0 ;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
