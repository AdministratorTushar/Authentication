package user_service;

import java.sql.Connection;
import java.sql.SQLException;

import userdao.UserDAO;
import userdto.UserDTO;
import userprofiledao.UserProfileDAO;
import userprofiledto.UserProfileDTO; 

public class UserService {
    private Connection connection;
    private UserDAO userDAO;
    private UserProfileDAO userProfileDAO;

    public UserService(Connection connection, UserDAO userDAO, UserProfileDAO userProfileDAO) {
        this.connection = connection;
        this.userDAO = userDAO;
        this.userProfileDAO = userProfileDAO;
    }

    public UserDTO getUserById(String userId) throws SQLException {
        return userDAO.getUserById(userId);
    }

    public boolean updateUserPassword(String userId, String newPassword) throws SQLException {
        return userDAO.updateUserPassword(userId, newPassword);
    }
    
    public boolean addUser(UserDTO user) throws SQLException {
    	return userDAO.addUser(user);
    } 

    public boolean addUserProfile(UserProfileDTO userProfile) throws SQLException {
        return userProfileDAO.addUserProfile(userProfile); 
    }

    public boolean updateUserProfile(UserProfileDTO userProfile) throws SQLException {
        return userProfileDAO.updateUserProfile(userProfile);
    }

	public String getUserNameById(String userId) throws SQLException {
		return userDAO.getUserNameById(userId);
	}
}