package userprofiledao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import userdao.UserDAO;
import userdto.UserDTO;
import userprofiledto.UserProfileDTO;

public class UserProfileDAO {
    private Connection connection;

    public UserProfileDAO(Connection connection) {
        this.connection = connection;
    }

    public boolean addUserProfile(UserProfileDTO userProfile) {
        String insertProfileQuery = "INSERT INTO user_info (userId, firstName, lastName, email, address, city, mobile) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement profileStatement = connection.prepareStatement(insertProfileQuery)) {
        	
                     
            profileStatement.setString(1, userProfile.getUserId());
            profileStatement.setString(2, userProfile.getFirstName());
            profileStatement.setString(3, userProfile.getLastName());
            profileStatement.setString(4, userProfile.getEmail());
            profileStatement.setString(5, userProfile.getAddress());
            profileStatement.setString(6, userProfile.getCity());
            profileStatement.setString(7, userProfile.getMobileNo());
            
            int rowsAffectedProfile = profileStatement.executeUpdate();
            
            return rowsAffectedProfile > 0; 
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean updateUserProfile(UserProfileDTO userProfile) {
        String sql = "UPDATE user_info SET firstName = ?, lastName = ?, email = ?, " +
                "address = ?, city = ?, mobile = ? WHERE userId = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, userProfile.getFirstName());
            statement.setString(2, userProfile.getLastName());
            statement.setString(3, userProfile.getEmail());
            statement.setString(4, userProfile.getAddress());
            statement.setString(5, userProfile.getCity());
            statement.setString(6, userProfile.getMobileNo());
            statement.setString(7, userProfile.getUserId());
            int rowsUpdated = statement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
